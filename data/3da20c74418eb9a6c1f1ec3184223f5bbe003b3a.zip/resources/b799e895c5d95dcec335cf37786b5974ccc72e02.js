class Worklet extends AudioWorkletProcessor {
    process(inputs, outputs, parameters) {
        let input = inputs[0][0];
        this.port.postMessage(input);
        return true;
    }
}

registerProcessor("main-recorder", Worklet);
